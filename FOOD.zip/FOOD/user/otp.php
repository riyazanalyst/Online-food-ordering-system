<?php include('../config/constant.php')?>
<link rel="stylesheet" href="../css/login.css">
<?php 
  if(isset($_GET['id']))
  {
    $ID = $_GET['id'];
    $sql = "SELECT * FROM tbl_user WHERE ID = '$ID'";

    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        $count = mysqli_num_rows($res);
        if($count==1)
        {
            $row = mysqli_fetch_assoc($res);
            $ID = $row['ID'];
            $OTP = $row['OTP'];
            $Password = $row['Password'];
        }
    }
  }
  ?>
<form class="login" method="POST">
  <h1 class="center">SIGNUP</h1>
  <h4 class="center color">Hey! Enter your details to sign up.</h4>
  <?php
  if(isset($_SESSION['otp']))
    {
        echo $_SESSION['otp'];
        unset ($_SESSION['otp']);
    } ?>
  <input type="text" name="otp" placeholder="OTP">
  <button name="submit">SIGNUP</button><br><br>
  Already Have an Account? <a href="../user/login.php">Login</a>
</form>
<?php 
   if(isset($_POST['submit']))
   {
     $otp = $_POST['otp'];


     $sql1 = "SELECT * FROM tbl_user WHERE ID = '$ID' AND OTP = '$otp'";

     $res1 = mysqli_query($conn, $sql1);
 
     $count = mysqli_num_rows($res1);

     if($count==1)
    {
      echo "verfied";
      header("location:".SITEURL.'');
      
    }
    else
    {
        $_SESSION['otp'] = "<div class='error'>Incorrect OTP</div>";
      
    }

   }
?>
