<?php include('../config/constant.php')?>
<link rel="stylesheet" href="../css/login.css">
<form class="login" method="POST">
  <h1 class="center">SIGNUP</h1>
  <h4 class="center color">Hey! Enter your details to sign up.</h4>
  <input type="hidden" name="ID" >
  <input type="text" name="Name" placeholder="Name">
  <input type="text" name="Phone" placeholder="Phone No">
  <button name="Get">Get OTP</button><br><br>
  Already Have an Account? <a href="../user/login.php">Login</a>
</form>
<?php 
  if(isset($_POST['Get']))
  {
    $ID = $_POST['ID'];
    $Name = $_POST['Name'];
    $Phone = $_POST['Phone'];
    
    $n=rand(1,5);
    $otp = $Phone*$n/100000000*20;
    $int_val = intval($otp);
     echo "$int_val";

   $sql = "INSERT INTO tbl_user SET
            
            Name = '$Name',
            PhoneNo = '$Phone',
            OTP = '$otp'
            ";

   $res = mysqli_query($conn, $sql);
   header('Location: '.SITEURLL.$ID);
  }
   ?>
   