<!-- social Section Starts Here -->
<section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="http://Wa.me//+919123581594"><img src="https://img.icons8.com/fluent/48/000000/whatsapp.png"/></a>
                </li>
                <li>
                    <a href="https://www.instagram.com/eren.yeagor/"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="https://twitter.com/vikramadityavg?s=09"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a style="color: white" href="https://www.instagram.com/eren.yeagor/">Sathishkumar</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>
<?php include('../FOOD/contact.php'); ?>