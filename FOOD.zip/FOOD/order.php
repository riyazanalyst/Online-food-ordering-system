<?php include('../FOOD/partials-front/menu.php'); ?>
<?php
if(isset($_GET['food_id']))
{
    $Food_ID = $_GET['food_id'];
    
    $sql = "SELECT * FROM tbl_food WHERE ID = '$Food_ID'";
    $res = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($res);

    if($count==1)
    {
        $row = mysqli_fetch_assoc($res);
        $Title = $row['Title'];
        $Price = $row['Price'];
        $Image = $row['Image'];
    }
    else
    {
        header('location:',SITEURL);
    }
}
else
{
    header('location:'.SITEURL);
}
?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search">
        <div class="container">
            
            <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

            <form method="POST" class="order" enctype="multipart/form-data">
                <fieldset>
                    <legend>Selected Food</legend>

                    <div class="food-menu-img">
                        <?php

                        if($Image=="")
                        {
                            echo "<div class='error'>Image Not Added</div>";
                        }
                        else
                        {
                            ?><img src="<?php echo SITEURL; ?>images/food/<?php echo $Image; ?>" alt="<?php echo $Title; ?>" class="img-responsive img-curve"><?php
                        }

                        ?>

                    </div>
    
                    <div class="food-menu-desc">
                        <h3><?php echo $Title; ?></h3>
                        <input type="hidden" name="food" value="<?php echo $Title; ?>">
                        <p class="food-price">Rs.<?php echo $Price; ?></p>
                        <input type="hidden" name="price" value="<?php echo $Price; ?>">
                        <div class="order-label">Quantity</div>
                        <input type="number" name="qty" class="input-responsive" value="1" required>
                        
                    </div>

                </fieldset>
                
                <fieldset>
                    <legend>Delivery Details</legend>
                    <div class="order-label">Full Name</div>
                    <input type="text" name="full-name" class="input-responsive" required>

                    <div class="order-label">Phone Number</div>
                    <input type="tel" name="contact" class="input-responsive" required>

                    <div class="order-label">Email</div>
                    <input type="email" name="email" class="input-responsive" required>

                    <div class="order-label">Address</div>
                    <textarea name="address" rows="10" class="input-responsive" required></textarea>
                    <h4>Payment</h4><br>
                    <input type="radio" name="active" value="Yes" class="radio">Cash On Delivery <br>
                    <img src="<?php echo SITEURL; ?>images/cod.png" alt="" class="img-curve" width="100"> <br>
                    <input type="radio" name="active" value="No" class="radio"> Net Banking <br><br>
                    <img src="<?php echo SITEURL; ?>images/nb.png" alt="" class="img-curve" width="60"><br> <br>
                    <input type="radio" name="active" value="Yes" class="radio"> UPI Payment <br> <br>
                    <img src="<?php echo SITEURL; ?>images/upi.png" alt="" class="img-curve" width="100"><br> <br>
                    <input type="submit" name="submit" value="Confirm Order" class="btn btn-primary">
                </fieldset>

            </form>

            <?php

            if(isset($_POST['submit']))
            {
                $Food = $_POST['food'];
                $Price = $_POST['price'];
                $Qty = $_POST['qty'];

                $Total = $Price * $Qty;

                $Order_date = date("Y-m-d h:i:sa");

                $Status = "Ordered";

                $Customer_name = $_POST['full-name'];
                $Customer_contact = $_POST['contact'];
                $Customer_email = $_POST['email'];
                $Customer_address = $_POST['address'];

                $sql1 = "INSERT INTO tbl_order SET
                    Food = '$Food',
                    Price = '$Price',
                    Quantity = '$Qty',
                    Total = '$Total',
                    Orderdate = '$Order_date',
                    Status = '$Status',
                    CustomerName = '$Customer_name',
                    CustomerContact = '$Customer_contact',
                    CustomerEmail = '$Customer_email',
                    CustomerAddress = '$Customer_address'
                "; 

                $res1 = mysqli_query($conn, $sql1);
                if($res1==TRUE)
                {
                    $_SESSION['order'] = "<div class='success text-center'>Order Confirmed</div>" ;
                    header('location:'.SITEURL);
                }
                else
                {
                    $_SESSION['order'] = "<div class='error text-center'>Order Failed Due to Technical Issues</div>" ;
                    header('location:'.SITEURL);
                }
            }

            ?>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->
    <?php include('../FOOD/partials-front/footer.php'); ?>