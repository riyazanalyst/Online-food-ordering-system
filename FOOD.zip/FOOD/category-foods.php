<?php include('../FOOD/partials-front/menu.php'); ?>

<?php 
    if(isset($_GET['category_id']))
    {
        $Category_ID = $_GET['category_id'];
        $sql = "SELECT * FROM tbl_category WHERE ID = '$Category_ID'";
        $res = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($res);
        $Category_title = $row['Title'];
    }
    else
    {
        header('location:'.SITEURL);
    }
?>
    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white">"<?php echo $Category_title; ?>"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>
            <?php
                $sql1 = "SELECT * FROM tbl_food WHERE Category_ID ='$Category_ID'";
                $res1 = mysqli_query($conn, $sql1);
                $count1 = mysqli_num_rows($res);

                if($count1>0)
                {
                    while($row1=mysqli_fetch_assoc($res1))
                    {
                        $ID = $row1['ID'];
                        $Title = $row1['Title'];
                        $Price = $row1['Price'];
                        $Description = $row1['Description'];
                        $Image = $row1['Image'];
                        ?>
                            <div class="food-menu-box">
                                <div class="food-menu-img">
                                    <?php
                                    if($Image=="")
                                    {
                                        echo "<div class='error'>Image Not Added</div>";
                                    }
                                    else
                                    {
                                        ?><img src="<?php echo SITEURL; ?>images/food/<?php echo $Image; ?>" alt="<?php echo $Title; ?>" class="img-responsive img-curve"><?php
                                    }
                                    ?>
                                    
                                </div>

                                <div class="food-menu-desc">
                                    <h4><?php echo $Title; ?></h4>
                                    <p class="food-price">Rs.<?php echo $Price; ?></p>
                                    <p class="food-detail">
                                        <?php echo $Description; ?>
                                    </p>
                                    <br>

                                    <a href="<?php echo SITEURL; ?>order.php?food_id=<?php echo $ID; ?>" class="btn btn-primary">Order Now</a>
                                </div>
                            </div>
                        <?php
                    }
                }
                else
                {
                    echo "<div class='error'>Food not Available</div>";
                }
            ?>
            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->
    <?php include('../FOOD/partials-front/footer.php'); ?>