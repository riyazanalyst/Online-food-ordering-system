<?php include('../FOOD/partials-front/menu.php'); ?>
    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            <?php $Search = $_POST['search'];?>
            <form action="<?php echo SITEURL; ?>food-search.php" method="POST">
                <input type="search" name="search" placeholder="Search for Food.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form><br><br>
            <h2>Foods on Your Search <a href="#" class="text-white">"<?php echo $Search; ?>"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <?php 

            $sql = "SELECT * FROM tbl_food WHERE Title LIKE '%$Search%' OR Description LIKE '%$Search%'";
            $res = mysqli_query($conn, $sql);
            $count = mysqli_num_rows($res);

            if($count>0)
            {
                while($row=mysqli_fetch_assoc($res))
                {
                    $ID = $row['ID'];
                    $Title = $row['Title'];
                    $Price = $row['Price'];
                    $Description = $row['Description'];
                    $Image = $row['Image'];  
                    ?>
                    <div class="food-menu-box">
                            <div class="food-menu-img">
                                <?php
                                if($Image=="")
                                {
                                    echo "<div class='error'>Image not Available</div>";
                                }
                                else
                                {
                                    ?><img src="<?php echo SITEURL; ?>images/food/<?php echo $Image ?>" alt="<?php echo $Title; ?>" class="img-responsive img-curve"><?php
                                }
                                ?>
                                
                            </div>

                        <div class="food-menu-desc">
                            <h4><?php echo $Title; ?></h4>
                            <p class="food-price">Rs.<?php echo $Price; ?></p>
                            <p class="food-detail">
                                <?php echo $Description; ?>
                            </p>
                            <br>

                            <a href="<?php echo SITEURL; ?>order.php?food_id=<?php echo $ID; ?>" class="btn btn-primary">Order Now</a>
                        </div>
                    </div>
                    <?php
                }
            }
            else
            {
                echo "<div class='error'>Food not found</div>";
            }

            ?>
            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->
    <?php include('../FOOD/partials-front/footer.php'); ?>