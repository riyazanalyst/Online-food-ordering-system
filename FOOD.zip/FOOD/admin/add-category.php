<?php include('../config/constant.php');?>
<link rel="stylesheet" href="../css/category.css">
<form class="category" method="POST" enctype="multipart/form-data">
    <h1 class="center">ADD CATEGORY</h1><br>
    <?php
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
    if(isset($_SESSION['upload']))
    {
        echo $_SESSION['upload'];
        unset ($_SESSION['upload']);
    }
    ?>
    <h3>TITLE</h3>
    <input type="text" name="title" placeholder="Category Title" class="box">
    <h3>IMAGE</h3>
    <input type="file" name="image" class="box">
    <h3>FEATURE</h3><input type="radio" name="feature" value="Yes" class="radio"> Yes
    <input type="radio" name="feature" value="No" class="radio"> No
    <h3>ACTIVE</h3><input type="radio" name="active" value="Yes" class="radio"> Yes
    <input type="radio" name="active" value="No" class="radio"> No <br> <br>
    <button name="add">ADD</button>
</form>

<?php
if(isset($_POST['add'])){
    $Title = $_POST['title'];

    if(isset($_POST['feature'])){

        $Feature = $_POST['feature'];
    }
    else{
        $Feature = "No";
    }
    if(isset($_POST['active'])){

        $Active = $_POST['active'];
    }
    else{
        $Active = "No";
    }

    //print_r($_FILES['image']);
    //die();
    if(isset($_FILES['image']['name'])){
        
        $image_name = $_FILES['image']['name'];

        if($image_name != "" )
        {
            //Uploading an Image
            $ext = end(explode('.',$image_name));
            $image_name = "Food_Category_".rand(000,999).'.'.$ext;
            $source_path = $_FILES['image']['tmp_name'];
            $destination_path  = "../images/category/".$image_name;
            $upload = move_uploaded_file($source_path, $destination_path);

            if($upload==FALSE){

                $_SESSION['upload'] = "<div class='error'>Failed to Upload Image</div>";
                die();
            }
        }
    }
    else{
        $image_name = "";
    }

    $sql = "INSERT INTO tbl_category SET
    Title = '$Title',
    Image = '$image_name',
    Featured = '$Feature',
    Active = '$Active'
    ";

    $res = mysqli_query($conn, $sql);
     
    if($res==TRUE){

        $_SESSION['add'] = "<div class='success'>Category Added Successfully</div>";
        header('location:'.SITEURL.'admin/manage-category.php');
    }
    else{

        $_SESSION['add'] = "<div class='error'>Failed to Add Category</div>";
    }
}
?>