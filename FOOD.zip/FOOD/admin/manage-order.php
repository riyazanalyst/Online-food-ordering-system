<?php include ('../admin/partials/menu.php')?>
<!-- Main Content Section Starts -->
<div class="main-content">
<div class="wrapper">
<h1>MANAGE ORDER</h1><br><br>
<?php
if(isset($_SESSION['update']))
    {
        echo $_SESSION['update'];
        unset ($_SESSION['update']);
    }
?>
<br><br>
<table class="tbl-full">
    <tr>
        <th>S.No</th>
        <th>Customer Name</th>
        <th>Food</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Total</th>
        <th>Order Date</th>
        <th>Contact</th>
        <th>Email</th>
        <th>Address</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php
    $sn = 1;
    $sql = "SELECT * FROM tbl_order ORDER BY ID DESC";
    $res = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($res);

    if($count>0)
    {
        while($row=mysqli_fetch_assoc($res))
        {
                $ID = $row['ID'];
                $Food = $row['Food'];
                $Price = $row['Price'];
                $Quantity = $row['Quantity'];
                $Total = $row['Total'];
                $Order_date = $row['Orderdate'];
                $Status = $row['Status'];
                $Customer_name = $row['CustomerName'];
                $Customer_contact = $row['CustomerContact'];
                $Customer_email = $row['CustomerEmail'];
                $Customer_address = $row['CustomerAddress'];
                ?>
                    <tr>
                        <td><?php echo $sn++; ?>.</td>
                        <td><?php echo $Customer_name; ?></td>
                        <td><?php echo $Food; ?></td>
                        <td>Rs.<?php echo $Price; ?></td>
                        <td><?php echo $Quantity; ?></td>
                        <td>Rs.<?php echo $Total; ?></td>
                        <td><?php echo $Order_date; ?></td>
                        <td><?php echo $Customer_contact; ?></td>
                        <td><?php echo $Customer_email; ?></td>
                        <td><?php echo $Customer_address; ?></td>
                        <td>
                            <?php

                            if($Status=="Ordered")
                            {
                                echo "<label>$Status</label>";
                            }
                            elseif($Status=="On Delivery")
                            {
                                echo "<label style='color: orange; '>$Status</label>";
                            }
                            elseif($Status=="Delivered")
                            {
                                echo "<label style='color: green; '>$Status</label>";
                            }
                            elseif($Status=="Cancelled")
                            {
                                echo "<label style='color: red; '>$Status</label>";
                            }

                            ?>
                        </td>
                        <td><a href="<?php echo SITEURL; ?>admin/update-order.php?id=<?php echo $ID; ?>" class="btn-secondary">UPDATE</a></td>
                    </tr>
                <?php
        }
    }
    else
    {
        echo "<tr><td colspan='12' class='error'>No Orders</td></tr>";
    }
    ?>
    
    
</table>
    
</div>
</div>
<!-- Main Content Setion Ends -->
<?php include ('../admin/partials/footer.php')?>