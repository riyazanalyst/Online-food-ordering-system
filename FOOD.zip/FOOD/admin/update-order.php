<?php include('../config/constant.php');

if(isset($_GET['id']))
{
    $ID = $_GET['id'];

    $sql = "SELECT * FROM tbl_order WHERE ID = '$ID'";
    $res = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($res);
    
    if($count==1)
    {
        $row = mysqli_fetch_assoc($res);
        $Food = $row['Food'];
        $Price = $row['Price'];
        $Quantity = $row['Quantity'];
        $Status = $row['Status'];
        $Customer_name = $row['CustomerName'];
        $Customer_contact = $row['CustomerContact'];
        $Customer_email = $row['CustomerEmail'];
        $Customer_address = $row['CustomerAddress'];
    }
    else
    {
        header('location:'.SITEURL.'admin/manage-order.php');
    }

}
else
{
    header('location:'.SITEURL.'admin/manage-order.php');
}

?>
<link rel="stylesheet" href="../css/order.css">
<form method="POST" class="order" enctype="multipart/form-data">
    <h1 class="center">UPDATE ORDER</h1>
    <?php
    if(isset($_SESSION['update']))
    {
        echo $_SESSION['update'];
        unset ($_SESSION['update']);
    }
    ?><br>
    <h3>FOOD NAME</h3><?php echo $Food; ?>
    <h3>PRICE</h3>Rs.<?php echo $Price; ?>
    <h3>QUANTITY</h3>
    <input type="number" name="qty" class="box" value="<?php echo $Quantity; ?>">
    <h3>STATUS</h3>
    <select name="status" class="box">
        <option <?php if($Status=="Ordered"){echo "selected";} ?> value="Ordered">Ordered</option>
        <option <?php if($Status=="On Delivery"){echo "selected";} ?> value="On Delivery">On Delivery</option>
        <option <?php if($Status=="Delivered"){echo "selected";} ?> value="Delivered">Delivered</option>
        <option <?php if($Status=="Cancelled"){echo "selected";} ?> value="Cancelled">Cancelled</option>
    </select>
    <h3>CUSTOMER NAME</h3>
    <input type="text" name="customer_name" class="box" value="<?php echo $Customer_name; ?>">
    <h3>CUSTOMER CONTACT</h3>
    <input type="text" name="customer_contact" class="box" value="<?php echo $Customer_contact; ?>">
    <h3>CUSTOMER EMAIL</h3>
    <input type="text" name="customer_email" class="box" value="<?php echo $Customer_email; ?>">
    <h3>CUSTOMER ADDRESS</h3>
    <textarea name="customer_address" class="box" cols="30" rows="5"><?php echo $Customer_address; ?></textarea>
    <input type="hidden" name="ID" value="<?php echo $ID; ?>">
    <input type="hidden" name="price" value="<?php echo $Price; ?>">
    <button name="update">UPDATE</button>
</form>

<?php

    if(isset($_POST['update']))
    {
        $ID = $_POST['ID'];
        $Price = $_POST['price'];
        $Quantity = $_POST['qty'];
        $Total = $Price * $Quantity;
        $Status = $_POST['status'];
        $Customer_name = $_POST['customer_name'];
        $Customer_contact = $_POST['customer_contact'];
        $Customer_email = $_POST['customer_email'];
        $Customer_address = $_POST['customer_address'];

        $sql1 = "UPDATE tbl_order SET
            Quantity = '$Quantity',
            Total = '$Total',
            Status = '$Status',
            CustomerName = '$Customer_name',
            CustomerContact = '$Customer_contact',
            CustomerEmail = '$Customer_email',
            CustomerAddress = '$Customer_address'
            WHERE ID = '$ID'
            ";

            $res1 = mysqli_query($conn, $sql1);

            if($res1==TRUE)
            {
                $_SESSION['update'] = "<div class='success'>Order Updated Successfully</div>";
                header('location:'.SITEURL.'admin/manage-order.php');
            }
            else
            {
                $_SESSION['update'] = "<div class='error'>Failed to Update Order</div>";
            }
    }

?>