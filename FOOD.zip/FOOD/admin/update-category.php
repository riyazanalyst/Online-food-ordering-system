<?php include('../config/constant.php')?>
<?php
if(isset($_GET['id']))
{
    $ID = $_GET['id'];

    $sql = "SELECT * FROM tbl_category WHERE ID = '$ID'";
    $res = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($res);

    if($count==1)
    {
        $row = mysqli_fetch_assoc($res);
        $Title = $row['Title'];
        $Current_image = $row['Image'];
        $Feature = $row['Featured'];
        $Active = $row['Active'];

    }
    else
    {
        $_SESSION['no-category'] = "<div class='error'>Category Not Found</div>";
        header('location:'.SITEURL.'admin/manage-category.php');
    }


}
else
{
    header('location:'.SITEURL.'admin/manage-category.php');
}
?>
<link rel="stylesheet" href="../css/category.css">
<form method="POST" enctype="multipart/form-data" class="category">
    <h1 class="center">UPDATE CATEGORY</h1>
    <?php
    if(isset($_SESSION['update']))
    {
        echo $_SESSION['update'];
        unset ($_SESSION['update']);
    }
    if(isset($_SESSION['upload']))
    {
        echo $_SESSION['upload'];
        unset ($_SESSION['upload']);
    }
    ?>
    <h3>TITLE</h3>
    <input type="text" name="title" class="box" value="<?php echo $Title; ?>">
    <h3>CURRENT IMAGE</h3>
    <?php
        if($Current_image!="")
        {
        ?>
            <img src="<?php echo SITEURL; ?>images/category/<?php echo $Current_image; ?>" width="150px">
        <?php
        }
        else
        {
            echo "<div class='error'>Image Not Found</div>";
        }
    ?>
    <h3>NEW IMAGE</h3>
    <input type="file" name="image" class="box">
    <h3>FEATURE</h3><input <?php if($Feature=="Yes"){echo "checked";}?> type="radio" name="feature" value="Yes" class="radio"> Yes
    <input <?php if($Feature=="No"){echo "checked";}?> type="radio" name="feature" value="No" class="radio"> No
    <h3>ACTIVE</h3><input <?php if($Active=="Yes"){echo "checked";}?> type="radio" name="active" value="Yes" class="radio"> Yes
    <input <?php if($Active=="No"){echo "checked";}?> type="radio" name="active" value="No" class="radio"> No <br> <br>
    <input type="hidden" name="current_image" value="<?php echo $Current_image; ?>">
    <input type="hidden" name="ID" value="<?php echo $ID; ?>">
    <button name="update">UPDATE</button>

</form>

<?php

if(isset($_POST['update']))
{
    $ID = $_POST['ID'];
    $Title = $_POST['title'];
    $Current_image = $_POST['current_image'];
    $Feature = $_POST['feature'];
    $Active = $_POST['active'];

    if(isset($_FILES['image']['name']))
    {
        $image_name = $_FILES['image']['name'];

        if($image_name!="")
        {
            //Upload New Image
            $ext = end(explode('.',$image_name));
            $image_name = "Food_Category_".rand(000,999).'.'.$ext;
            $source_path = $_FILES['image']['tmp_name'];
            $destination_path  = "../images/category/".$image_name;
            $upload = move_uploaded_file($source_path, $destination_path);

            if($upload==FALSE){

                $_SESSION['upload'] = "<div class='error'>Failed to Upload Image</div>";
                die();
            }

            //Remove Previous Image If Available
            if($Current_image!="")
            {
                $remove_path = "../images/category/".$Current_image;
            $remove = unlink($remove_path);

            if($remove==FALSE)
            {
                $_SESSION['failed'] = "<div class='error'>Failed to Remove Current Image</div>";
                die();
                header('location:'.SITEURL.'admin/manage-category.php');
            }
            }

        }
        else
        {
            $image_name = $Current_image;
        }
    }
    else
    {
        $image_name = $Current_image;
    }

    $sql1 = "UPDATE tbl_category SET
        Title = '$Title',
        Image =  '$image_name',
        Featured = '$Feature',
        Active = '$Active'
        WHERE ID = '$ID'
    ";

    $res1 = mysqli_query($conn, $sql1);

    if($res1==TRUE)
    {
        $_SESSION['update'] = "<div class='success'>Category Updated Successfully</div>";
        header('location:'.SITEURL.'admin/manage-category.php');
    }
    else
    {
        $_SESSION['update'] = "<div class='error'>Failed to Update Category</div>";
    }
    
}

?>



