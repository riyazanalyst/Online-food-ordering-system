<?php include('../config/constant.php')?>
<link rel="stylesheet" href="../css/login.css">
<form class="login" method="POST">
  <h1 class="center">SIGNUP</h1>
  <h4 class="center color">Hey! Enter your details to sign up.</h4>
  <?php 
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
?>
  <input type="text" name="ID" placeholder="User ID">
  <input type="text" name="Username" placeholder="Username">
  <input type="text" name="Fullname" placeholder="Fullname">
  <input type="password" name="Password" placeholder="Password">
  <button name="submit">SIGNUP</button><br><br>
  Already Have an Account? <a href="../admin/login.php">Login</a>
</form>
<?php 
  if(isset($_POST['submit']))
  {
    $ID = $_POST['ID'];
    $Fullname = $_POST['Fullname'];
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    $sql = "INSERT INTO tbl_admin SET
            ID = '$ID',
            Fullname = '$Fullname',
            Username = '$Username',
            Password = '$Password'
            ";

    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        $_SESSION['add'] = "<div class='success'>Admin Added Successfully</div>";
        header("location:".SITEURL.'admin/manage-admin.php');
    }
    else
    {
        $_SESSION['add'] = "<div class='error'>Failed to Add Admin</div>";
    }
  }
?>
