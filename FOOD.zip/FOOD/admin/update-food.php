<?php
include('../config/constant.php');

if(isset($_GET['id']))
{
    $ID = $_GET['id'];
    $sql1 = "SELECT * FROM tbl_food WHERE ID = $ID";
    $res1 = mysqli_query($conn, $sql1);
    $count1 = mysqli_num_rows($res1);

    if($count1==1)
    {
        $row1 = mysqli_fetch_assoc($res1);
        $Title = $row1['Title'];
        $Description = $row1['Description'];
        $Price = $row1['Price'];
        $Current_image = $row1['Image'];
        $Current_category = $row1['Category_ID'];
        $Feature = $row1['Featured'];
        $Active = $row1['Active'];
    }
}
else
{
    header('location:'.SITEURL.'admin/manage-food.php');
}
?>
<link rel="stylesheet" href="../css/food.css">
<form method="POST" class="food" enctype="multipart/form-data">
<h1 class="center">UPDATE FOOD</h1>
<?php
if(isset($_SESSION['update']))
{
    echo $_SESSION['update'];
    unset ($_SESSION['update']);
}
if(isset($_SESSION['upload']))
{
    echo $_SESSION['upload'];
    unset ($_SESSION['upload']);
}
?>
<h3>TITLE</h3>
<input type="text" name="title" value="<?php echo $Title; ?>" class="box">
<h3>DESCRIPTION</h3>
<textarea name="description" cols="30" rows="5" class="box"><?php echo $Description; ?></textarea>
<h3>PRICE</h3>
<input type="number" name="price" class="box" value="<?php echo $Price; ?>">
<h3>CURRENT IMAGE</h3>
<?php
if($Current_image!="")
{
?>
    <img src="<?php echo SITEURL; ?>images/food/<?php echo $Current_image; ?>" width="150px">
<?php
}
else
{
    echo "<div class='error'>Image Not Found</div>";
}
?>
<h3>NEW IMAGE</h3>
<input type="file" name="image" class="box">
<h3>CATEGORY</h3>
<select name="category" class="box">
    <?php
        $sql = "SELECT * FROM tbl_category WHERE Active = 'Yes'";
        $res = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($res);

        if($count>0)
        {
            while($row=mysqli_fetch_assoc($res))
            {
                $Category_title = $row['Title'];
                $Category_ID = $row['ID'];

                //echo "<option value='$Category_ID'>$Category_title</option>";
                ?>
                <option <?php if($Current_category==$Category_ID){echo "Selected";} ?> value="<?php echo $Category_ID; ?>"><?php echo $Category_title; ?></option>
                <?php
            }
        }
        else
        {
            echo "<option value='0'>No Category Available</option>";
        }
    ?>
</select>
<h3>FEATURE</h3><input <?php if($Feature=="Yes"){echo "checked";}?> type="radio" name="feature" value="Yes" class="radio"> Yes
<input <?php if($Feature=="No"){echo "checked";}?> type="radio" name="feature" value="No" class="radio"> No
<h3>ACTIVE</h3><input <?php if($Active=="Yes"){echo "checked";}?> type="radio" name="active" value="Yes" class="radio"> Yes
<input <?php if($Active=="No"){echo "checked";}?> type="radio" name="active" value="No" class="radio"> No <br> <br>
<input type="hidden" name="current_image" value="<?php echo $Current_image; ?>">
<input type="hidden" name="ID" value="<?php echo $ID; ?>">
<button name="update">UPDATE</button>
</form>

<?php
    if(isset($_POST['update']))
    {
        $ID = $_POST['ID'];
        $Title = $_POST['title'];
        $Description = $_POST['description'];
        $Price = $_POST['price'];
        $Current_image = $_POST['current_image'];
        $Category = $_POST['category'];
        $Feature = $_POST['feature'];
        $Active = $_POST['active'];

        if(isset($_FILES['image']['name']))
        {
            $image_name = $_FILES['image']['name'];
            
            if($image_name!="")
            {
                //Upload New Image
                $ext = end(explode('.',$image_name));
                $image_name = "Food_Name_".rand(000,999).'.'.$ext;
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path  = "../images/food/".$image_name;
                $upload = move_uploaded_file($source_path, $destination_path);

                if($upload==FALSE){

                    $_SESSION['upload'] = "<div class='error'>Failed to Upload Image</div>";
                    die();
                }

                //Remove Previous Image If Available
                if($Current_image!="")
                {
                    $remove_path = "../images/food/".$Current_image;
                    $remove = unlink($remove_path);

                    if($remove==FALSE)
                    {
                        $_SESSION['failed'] = "<div class='error'>Failed to Remove Current Image</div>";
                        die();
                        header('location:'.SITEURL.'admin/manage-food.php');
                    }
                }

            }
            else
            {
                $image_name = $Current_image;
            }
        }
        else
        {
            $image_name = $Current_image;
        }

        $sql2 = "UPDATE tbl_food SET
        Title = '$Title',
        Description = '$Description',
        Price = '$Price',
        Image =  '$image_name',
        Category_ID = '$Category',
        Featured = '$Feature',
        Active = '$Active'
        WHERE ID = '$ID'
        ";

        $res2 = mysqli_query($conn, $sql2);

        if($res2==TRUE)
        {
            $_SESSION['update'] = "<div class='success'>Food Updated Successfully</div>";
            header('location:'.SITEURL.'admin/manage-food.php');
        }
        else
        {
            $_SESSION['update'] = "<div class='error'>Failed to Update Food</div>";
        }
    
    }
?>