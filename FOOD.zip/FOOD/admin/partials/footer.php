<!-- Footer Section Starts -->
<div class="footer">
<div class="wrapper">
<p class="text-center">2023 All rights reserved, Some Restaurant. Developed By <a href="#">Sathishkumar</a></p></div>
</div>
<!-- Footer Section Ends -->
</body>
</html>
