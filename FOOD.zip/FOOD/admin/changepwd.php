<?php include('../config/constant.php')?>
<link rel="stylesheet" href="../css/login.css">
<form class="login" method="POST">
  <h1 class="center">CHANGE PASSWORD</h1>
  <?php 
    if(isset($_SESSION['change-pwd']))
    {
        echo $_SESSION['change-pwd'];
        unset($_SESSION['change-pwd']);
    }
    if(isset($_SESSION['user-not-found']))
    {
        echo $_SESSION['user-not-found'];
        unset($_SESSION['user-not-found']);
    }
    if(isset($_SESSION['pwd-not-match']))
    {
        echo $_SESSION['pwd-not-match'];
        unset($_SESSION['pwd-not-match']);
    }
    $ID = $_GET['id'];
  ?>
  <input type="hidden" name="ID" value="<?php echo $ID;?>" >
  <input type="password" name="Current_Password" placeholder="Current Password">
  <input type="password" name="New_Password" placeholder="New Password">
  <input type="password" name="Confirm_Password" placeholder="Confirm Password">
  <button name="submit">DONE</button>
</form>
<?php 
if(isset($_POST['submit']))
{
    $ID = $_POST['ID'];
    $Current_Password = $_POST['Current_Password'];
    $New_Password = $_POST['New_Password'];
    $Confirm_Password = $_POST['Confirm_Password'];

    $sql = "SELECT * FROM tbl_admin WHERE ID = '$ID' AND Password = '$Current_Password'";
    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        $count = mysqli_num_rows($res);

        if($count==1)
        {
            if($New_Password==$Confirm_Password)
            {
                $sql1 = "UPDATE tbl_admin SET Password = '$New_Password' WHERE ID = '$ID' ";
                $res1 = mysqli_query($conn, $sql1);

                if($res1==TRUE)
                {
                    $_SESSION['change-pwd'] = "<div class='success'>Password Changed Successfully</div>";
                    header("location:".SITEURL.'admin/manage-admin.php');
                    exit; // Exit after setting the session and redirect
                }
            }
            else
            {
                $_SESSION['pwd-not-match'] = "<div class='error'>Password Didn't Match</div>";
                header("location:".SITEURL.'admin/changepwd.php?id='.$ID); // Redirect back to the change-password.php page
                exit; // Exit after setting the session and redirect
            }
        }
        else
        {
            $_SESSION['user-not-found'] = "<div class='error'>Incorrect Password</div>";
            header("location:".SITEURL.'admin/changepwd.php?id='.$ID); // Redirect back to the change-password.php page
            exit; // Exit after setting the session and redirect
        }
    }
} 
?>
