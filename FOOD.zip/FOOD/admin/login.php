<?php include('../config/constant.php')?>
<link rel="stylesheet" href="../css/login.css">
<form class="login" method="POST">
  <h1 class="center">LOGIN</h1>
  <h4 class="center color">Hey! Enter your details to Login.</h4>
  <?php 
    if(isset($_SESSION['login']))
    {
        echo $_SESSION['login'];
        unset ($_SESSION['login']);
    } 
    if(isset($_SESSION['no-login-message']))
    {
        echo $_SESSION['no-login-message'];
        unset ($_SESSION['no-login-message']);
    } 
?><br>
  <input type="text" name="Username" placeholder="Username">
  <input type="password" name="Password" placeholder="Password">
  <button name="submit">LOGIN</button><br><br>
  Don't Have an Account? <a href="../admin/add-admin.php">Register</a>
</form>

<?php 

if(isset($_POST['submit']))
{
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    $sql = "SELECT * FROM tbl_admin WHERE Username = '$Username' AND Password = '$Password'";

    $res = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($res);

    if($count==1)
    {
      $_SESSION['login'] = "<div class='success'><h3>Hello $Username</h3></div>";
      $_SESSION['user'] = $Username;
      header("location:".SITEURL.'admin/');
      
    }
    else
    {
      $_SESSION['login'] = "<div class='error'>Invalid Username or Password</div>";
      header("location:".SITEURL.'admin/login.php');
    }
}

?>