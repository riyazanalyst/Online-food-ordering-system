<?php include('../config/constant.php');?>
<link rel="stylesheet" href="../css/food.css">
<form class="food" method="POST" enctype="multipart/form-data">
    <h1 class="center">ADD FOOD</h1>
    <?php
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
    if(isset($_SESSION['upload']))
    {
        echo $_SESSION['upload'];
        unset ($_SESSION['upload']);
    }
    ?>
    <h3>TITLE</h3>
    <input type="text" name="title" placeholder="Food Title" class="box">
    <h3>DESCRIPTION</h3>
    <textarea name="description" cols="30" rows="5" placeholder="Description of the food" class="box"></textarea>
    <h3>PRICE</h3>
    <input type="number" name="price" class="box" placeholder="Rs">
    <h3>IMAGE</h3>
    <input type="file" name="image" class="box">
    <h3>CATEGORY</h3>
    <select name="category" class="box">
        <?php
            $sql = "SELECT * FROM tbl_category WHERE Active = 'Yes'";
            $res = mysqli_query($conn, $sql);
            $count = mysqli_num_rows($res);

            if($count>0)
            {
                while($row=mysqli_fetch_assoc($res))
                {
                    $ID = $row['ID'];
                    $Title = $row['Title'];
                    ?>
                    <option value="<?php echo $ID; ?>"><?php echo $Title; ?></option>
                    <?php
                }
            }
            else
            {
                ?>
                <option value="0">No Category Found</option>
                <?php
            }
        ?>
    </select>
    <h3>FEATURE</h3><input type="radio" name="feature" value="Yes" class="radio"> Yes
    <input type="radio" name="feature" value="No" class="radio"> No
    <h3>ACTIVE</h3><input type="radio" name="active" value="Yes" class="radio"> Yes
    <input type="radio" name="active" value="No" class="radio"> No <br> <br>
    <button name="add">ADD</button>
</form>

<?php

    if(isset($_POST['add']))
    {
        $Title = $_POST['title'];
        $Description = $_POST['description'];
        $Price = $_POST['price'];
        $Category = $_POST['category'];

        if(isset($_POST['feature'])){

            $Feature = $_POST['feature'];
        }
        else{
            $Feature = "No";
        }
        if(isset($_POST['active'])){
    
            $Active = $_POST['active'];
        }
        else{
            $Active = "No";
        }
        if(isset($_FILES['image']['name'])){
        
            $image_name = $_FILES['image']['name'];

            if($image_name != "" )
            {
                $ext = end(explode('.',$image_name));
                $image_name = "Food_Name_".rand(000,999).'.'.$ext;
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path  = "../images/food/".$image_name;
                $upload = move_uploaded_file($source_path, $destination_path);

                if($upload==FALSE){

                    $_SESSION['upload'] = "<div class='error'>Failed to Upload Image</div>";
                    die();
                }
            }
        }
        else{
            $image_name = "";
        }

        $sql1 = "INSERT INTO tbl_food SET
            Title = '$Title',
            Description = '$Description',
            Price = '$Price',
            Image = '$image_name',
            Category_ID = '$Category',
            Featured = '$Feature',
            Active = '$Active'
        ";

        $res1 = mysqli_query($conn, $sql1);

        if($res1==TRUE)
        {
            $_SESSION['add'] = "<div class='success'>Food Added Successfully</div>";
            header('location:'.SITEURL.'admin/manage-food.php');
        }
        else
        {
            $_SESSION['add'] = "<div class='error'>Failed to Add Food</div>";
        }
        
    }

?>