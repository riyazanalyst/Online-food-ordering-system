<?php include ('../admin/partials/menu.php')?>
<!-- Main Content Section Starts -->
<div class="main-content">
<div class="wrapper">
<h1>MANAGE CATEGORY</h1><br><br>
<?php
if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
if(isset($_SESSION['remove']))
    {
        echo $_SESSION['remove'];
        unset ($_SESSION['remove']);
    }
if(isset($_SESSION['delete']))
    {
        echo $_SESSION['delete'];
        unset ($_SESSION['delete']);
    }
if(isset($_SESSION['no-category']))
    {
        echo $_SESSION['no-category'];
        unset ($_SESSION['no-category']);
    }
if(isset($_SESSION['update']))
    {
        echo $_SESSION['update'];
        unset ($_SESSION['update']);
    }
if(isset($_SESSION['failed']))
    {
        echo $_SESSION['failed'];
        unset ($_SESSION['failed']);
    }
    ?> <br> <br>
    <a href="add-category.php" class="btn-primary">ADD CATEGORY</a><br><br>
    <table class="tbl-full">
        <tr>
            <th>S No</th>
            <th>Title</th>
            <th>Image</th>
            <th>Feature</th>
            <th>Active</th>
            <th>Actions</th>
        </tr>

            <?php
                $n=1;

                $sql = "SELECT * FROM tbl_category";

                $res = mysqli_query($conn, $sql);

                $count = mysqli_num_rows($res);
                
                if($count>0){

                    while($row=mysqli_fetch_assoc($res))
                    {
                        $ID = $row['ID'];
                        $Title = $row['Title'];
                        $Image = $row['Image'];
                        $Feature = $row['Featured'];
                        $Active = $row['Active'];

                        ?>

                            <tr>
                                <td><?php echo $n++;?>.</td>
                                <td><?php echo $Title;?></td>
                                <td>
                                    <?php 
                                        if($Image!="")
                                        {
                                            ?>
                                            <img src="<?php echo SITEURL;?>images/category/<?php echo $Image; ?>" width="120px">
                                            <?php
                                        }
                                        else
                                        {
                                            echo "<div class='error'>Image not Found!</div>";
                                        }
                                    ?>
                                </td>
                                <td><?php echo $Feature;?></td>
                                <td><?php echo $Active;?></td>
                                <td>
                                    <a href="<?php echo SITEURL;?>admin/update-category.php?id=<?php echo $ID; ?>" class="btn-secondary">UPDATE</a>
                                    <a href="<?php echo SITEURL;?>admin/delete-category.php?id=<?php echo $ID; ?>&Image_name=<?php echo $Image; ?>" class="btn-danger">DELETE</a>
                                </td>
                            </tr>

                        <?php
                    }
                    
                }
                else{
                    ?>

                    <tr>
                        <td colspan="6"><div class="error">No Category Added</div></td>
                    </tr>

                    <?php
                }

            ?>
    </table>
    
</div>
</div>
<!-- Main Content Setion Ends -->
<?php include ('../admin/partials/footer.php')?>