<?php include('../config/constant.php')?>
<link rel="stylesheet" href="../css/login.css">
<form class="login" method="POST">
  <h1 class="center">UPDATE ADMIN</h1>
  <?php 
    if(isset($_SESSION['upd']))
    {
        echo $_SESSION['upd'];
        unset ($_SESSION['upd']);
    }
?>
  <?php 
  $ID = $_GET['id'];
    $sql = "SELECT * FROM tbl_admin WHERE ID = '$ID'";

    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        $count = mysqli_num_rows($res);
        if($count==1)
        {
            $row = mysqli_fetch_assoc($res);
            $Fullname = $row['Fullname'];
            $Username = $row['Username'];
        }
        else
        {
            header('location:'.SITEURL.'admin/manage-admin.php');
        }
    }
  ?>
  <input type="hidden" name="ID" value="<?php echo $ID;?>" >
 <input type="text" name="Username" value="<?php echo $Username?>">
 <input type="text" name="Fullname" value="<?php echo $Fullname?>">
  <button name="submit">UPDATE</button>
</form>
<?php

        if(isset($_POST['submit']))
        {
            $ID = $_POST['ID'];
            $Fullname = $_POST['Fullname'];
            $Username = $_POST['Username'];

            $sql1 = "UPDATE tbl_admin SET
            Fullname = '$Fullname',
            Username = '$Username'
            WHERE ID = '$ID'";

            $res1 = mysqli_query($conn, $sql1);

            if($res1==TRUE)
            {
                $_SESSION['upd'] = "<div class='success'>Admin Updated Successfully</div>";
                header("location:".SITEURL.'admin/manage-admin.php');
            }
            else
            {
                $_SESSION['upd'] = "<div class='success'>Failed to Update Admin</div>";
        
            }
        }

?>
