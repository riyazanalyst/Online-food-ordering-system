<?php
include('../config/constant.php');

if(isset($_GET['id']) AND isset($_GET['Image_name']))
{
    $ID = $_GET['id'];
    $Image = $_GET['Image_name'];

    if($Image!="")
    {
        $path = "../images/food/".$Image;
        $remove = unlink($path);

        if($remove==FALSE)
        {
            $_SESSION['remove'] = "<div class='error'>Failed to Remove File</div>";
            header('location:'.SITEURL.'admin/manage-food.php');
            die();
        }
    }

    $sql = "DELETE FROM tbl_food WHERE ID = '$ID'";

    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        $_SESSION['delete'] = "<div class='success'>Food Deleted Successfully</div>";
        header('location:'.SITEURL.'admin/manage-food.php');
    }
    else
    {
        $_SESSION['delete'] = "<div class='error'>Failed to Delete Food</div>";
        header('location:'.SITEURL.'admin/manage-food.php');
    }
}
else
{
    $_SESSION['unauthorize'] = "<div class='error'>Unauthorized Access</div>";
    header('location:'.SITEURL.'admin/manage-food.php');
}

?>