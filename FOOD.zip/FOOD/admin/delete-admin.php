<?php 
    include('../config/constant.php');
    echo $ID = $_GET['id'];


        $sql = "DELETE FROM tbl_admin WHERE ID = '$ID'";

        $res = mysqli_query($conn, $sql);

        if($res == TRUE)
        {
            $_SESSION['delete'] = "<div class='success'>Admin Deleted Successfully</div>";
            header("location:".SITEURL.'admin/manage-admin.php');
        } else {
            $_SESSION['delete'] = "<div class='error'>Failed to Delete Admin</div>";
            header("location:".SITEURL.'admin/manage-admin.php');
        }
        
?>
