<?php include ('../admin/partials/menu.php')?>
<!-- Main Content Section Starts -->
<div class="main-content">
<div class="wrapper">
<h1>MANAGE FOOD</h1><br><br>
<?php 
$n=1;
if(isset($_SESSION['add']))
{
    echo $_SESSION['add'];
    unset ($_SESSION['add']);
}
if(isset($_SESSION['update']))
{
    echo $_SESSION['update'];
    unset ($_SESSION['update']);
}
if(isset($_SESSION['delete']))
{
    echo $_SESSION['delete'];
    unset ($_SESSION['delete']);
}
if(isset($_SESSION['remove']))
{
    echo $_SESSION['remove'];
    unset ($_SESSION['remove']);
}
if(isset($_SESSION['unauthorize']))
{
    echo $_SESSION['unauthorize'];
    unset ($_SESSION['unauthorize']);
}
?>
<br><br>
<a href="add-food.php" class="btn-primary">ADD FOOD</a><br><br>
<table class="tbl-full">
    <tr>
        <th>S No</th>
        <th>Title</th>
        <th>Image</th>
        <th>Price</th>
        <th>Feature</th>
        <th>Active</th>
        <th>Actions</th>
    </tr>

    <?php
        $sql = "SELECT * FROM tbl_food";
        $res = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($res);

        if($count>0)
        {
            while($row=mysqli_fetch_assoc($res))
            {
                $ID = $row['ID'];
                $Title = $row['Title'];
                $Price = $row['Price'];
                $Image = $row['Image'];
                $Feature = $row['Featured'];
                $Active = $row['Active'];

                ?>
                <tr>
                    <td><?php echo $n++; ?>.</td>
                    <td><?php echo $Title; ?></td>
                    <td><?php 
                            if($Image!="")
                            {
                                ?>
                                <img src="<?php echo SITEURL;?>images/food/<?php echo $Image; ?>" width="120px">
                                <?php
                            }
                            else
                            {
                                echo "<div class='error'>Image not Found!</div>";
                            }
                        ?>
                    </td>
                    <td>Rs.<?php echo $Price; ?></td>
                    <td><?php echo $Feature; ?></td>
                    <td><?php echo $Active; ?></td>
                    <td>
                    <a href="<?php echo SITEURL;?>admin/update-food.php?id=<?php echo $ID; ?>" class="btn-secondary">UPDATE</a>
                    <a href="<?php echo SITEURL;?>admin/delete-food.php?id=<?php echo $ID; ?>&Image_name=<?php echo $Image; ?>" class="btn-danger">DELETE</a>
                    </td>
                </tr>
                <?php

            }
        }
        else
        {
            echo "<tr> <td colspan=7 class='error'>Food Not Added Yet</td></tr>";
        }
    ?>

    

</table>
    
</div>
</div>
<!-- Main Content Setion Ends -->
<?php include ('../admin/partials/footer.php')?>