<?php include('../FOOD/partials-front/menu.php'); ?>

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <?php 
            
            $sql = "SELECT * FROM tbl_category WHERE Active='Yes'";
            $res = mysqli_query($conn, $sql);
            $count = mysqli_num_rows($res);

            if($count>0)
            {
                while($row=mysqli_fetch_assoc($res))
                {
                    $ID = $row['ID'];
                    $Title = $row['Title'];
                    $Image = $row['Image'];

                    ?>
                    
                        <a href="<?php echo SITEURL; ?>category-foods.php?category_id=<?php echo $ID; ?>">
                        <div class="box-3 float-container">
                            <?php
                            if($Image=="")
                            {
                                echo "<div class='error'>Image Not Added</div>";
                            }
                            else
                            {
                                ?>
                                <img src="<?php echo SITEURL; ?>images/category/<?php echo $Image; ?>" alt="<?php echo $Title; ?>" class="img-responsive img-curve">;
                                <?php
                            }
                            ?>
                            

                            <h3 class="float-text text-white"><?php echo $Title; ?></h3>
                        </div>
                        </a>

                    <?php
                }
            }   
            else
            {
                echo "<div class='error'>Category Not Found</div>";
            }         
            ?>
            

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->


    <?php include('../FOOD/partials-front/footer.php'); ?>